from boa.compiler import Compiler

Compiler.load_and_save('ico_template.py')
